APPLETINI DEMOS

Extract Appletini_Demos.po and boot it from an Appletini SmartPort drive.
Select M: MUSIC - HOUSE OF THE RISING SUN, then press Return.
Music requires a 65C02, Appletini One F1.2.4 and native Phasor in slot 4.
P=PAL, N=NTSC, R=replay, Space=stop, Q/Escape=return to the menu.
Both regional songs preload into RAM; playback has no disk reads.

The image passed software checks; physical Appletini playback and
a complete ROM/BASIC boot have not been tested.
